package com.company.comand;

public interface Comand {
    void execute();
}


